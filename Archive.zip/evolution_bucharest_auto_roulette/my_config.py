import numpy as np
from mss import mss
from tool import my_image_grab_tool as migt


'''
Monitor(x=0, y=0, width=1792, height=1120, width_mm=None, height_mm=None, name=None, is_primary=True)
Monitor(x=1792, y=604, width=1920, height=1080, width_mm=None, height_mm=None, name=None, is_primary=False)
Monitor(x=-128, y=1120, width=1920, height=1080, width_mm=None, height_mm=None, name=None, is_primary=False)
'''

sct = mss()
monitor_number = 3
mon = sct.monitors[monitor_number]

# 預設一個
default_bounding_box = {'top': 100, 'left': 100, 'width': 100, 'height': 100, "mon": monitor_number}
# 螢幕截圖 - 輪盤
roulette_bounding_box = {'top': mon["top"] + 90, 'left': mon["left"] + 78, 'width': 440, 'height': 356,
                         "mon": monitor_number}
# 螢幕截圖 - 狀態判斷
status_bounding_box = {'top': mon["top"] + 940, 'left': mon["left"] + 828, 'width': 266, 'height': 30,
                       "mon": monitor_number}
# 螢幕截圖 - 結果判斷
result_bounding_box = {'top': mon["top"] + 980, 'left': mon["left"] + 930, 'width': 60, 'height': 64,
                       "mon": monitor_number}
