import cv2
import numpy as np
import time
from threading import Thread
from multiprocessing import Process
from screeninfo import get_monitors
import my_config as mc
import roulette_image_tool as rit
from tool import my_image_draw_tool as midt
from tool import my_roulette_tool as mrt
from tool import my_image_grab_tool as migt

for m in get_monitors():
    print(str(m))


# 把要螢幕截屏的範圍定位出來
default_bounding_box = {'top': 100, 'left': 100, 'width': 100, 'height': 100, "mon": 1}
roulette_bounding_box = mc.roulette_bounding_box
status_bounding_box = mc.status_bounding_box
result_bounding_box = mc.result_bounding_box

# 執行螢幕截屏from playsound import playsound
roulette_img = migt.get_grab_image(roulette_bounding_box)
status_img = migt.get_grab_image(status_bounding_box)
result_img = migt.get_grab_image(result_bounding_box)
info_img = migt.get_grab_image(default_bounding_box)

# 建立預設的圖片
roulette_img_o = np.full((1, 1, 3), (0, 0, 0), np.uint8)
status_img_o = np.full((1, 1, 3), (0, 0, 0), np.uint8)
result_img_o = np.full((1, 1, 3), (0, 0, 0), np.uint8)


status_text = 'None'
result_text = 'None'

can_bet = False
can_bet_text = ''

zero_angle = 0
result_angle = 0
start_angle = 0
start_num = 0
result_num = 0


# 把圖形辨識的結果放入變數
def get_ocr_text():
    while True:
        global status_text
        status_text = rit.get_ocr_text(status_img_o)
        global result_text

        # 防止bet的圖案也會被視為數字
        if not status_text == 'PLACE YOUR BETS' or not status_text == 'BETS CLOSING':
            result_text = rit.get_ocr_text_num(result_img_o)

        global result_num
        result_num = result_text if result_text.isdigit() else result_num
        global zero_angle
        global result_angle
        result_angle = mrt.get_euro_num_angle(zero_angle, result_text)
        # print(f'下注文字：{status_text}')
        # print(f'結果文字：{result_text}')
        time.sleep(0.01)


# 把圖型辦識結果的變數來執行判斷
# https://stackoverflow.com/questions/67177261/accessing-a-variable-value-outside-of-a-while-loop
def get_status_text():
    while True:
        global can_bet
        global can_bet_text
        global status_text
        if status_text == 'PLACE YOUR BETS' or status_text == 'BETS CLOSING':
            can_bet = True
            can_bet_text = 'YES'
        else:
            can_bet = False
            can_bet_text = 'NO'
        time.sleep(0.01)

'''
# 結束時資料庫需求數據：

往左往右
球射出至closing bet的時間

初始數字
初始數字位置(角度)
初始0位置(角度)

結束號碼

'''
is_clockwise_record = False
is_time_record = False
is_start_num_record = False
is_start_angle_record = False
is_start_0_record = False
is_end_num_record = False

is_spin = True
is_clockwise = True
spin_time = 0


previous_angle = 360
now_angle = 0
previous_time = time.time()
now_time = time.time()


def get_finish_status():
    while True:
        global previous_angle
        global now_angle
        global is_spin
        previous_angle = zero_angle
        time.sleep(0.15)
        now_angle = zero_angle
        global start_num
        if previous_angle == now_angle:
            is_spin = False
            start_num = result_num
        else:
            is_spin = True


t2 = Thread(target=get_ocr_text)
t2.start()
t3 = Thread(target=get_status_text)
t3.start()
t4 = Thread(target=get_finish_status)
t4.start()

while True:

    info_pic = np.full((500, 500, 3), (255, 255, 255), np.uint8)
    roulette_img = migt.get_grab_image(roulette_bounding_box)
    status_img = migt.get_grab_image(status_bounding_box)
    result_img = migt.get_grab_image(result_bounding_box)

    roulette_coordinate = rit.get_coordinate(roulette_img)
    zero_angle = roulette_coordinate['a']
    roulette_img_o = rit.roulette_img_drawn(roulette_img, roulette_coordinate)
    status_img_o = rit.status_img_operation(status_img)
    result_img_o = rit.result_img_operation(result_img)

    cv2.imshow('roulette', roulette_img)
    cv2.imshow('status', status_img)
    cv2.imshow('result', result_img)

    cv2.imshow('roulette_o', roulette_img_o)
    cv2.imshow('status_o', status_img_o)
    cv2.imshow('result_o', result_img_o)

    info_img = midt.draw_text(info_pic, 10, 10, f'下注文字：{status_text}', (0, 0, 0), 24)
    info_img = midt.draw_text(info_img, 10, 50, f'結果文字：{result_text}', (0, 0, 0), 24)
    info_img = midt.draw_text(info_img, 10, 100, f'可否下注：{can_bet_text}', (0, 0, 0), 24)
    info_img = midt.draw_text(info_img, 10, 150, f'0號角度：{zero_angle}。', (0, 0, 0), 24)
    info_img = midt.draw_text(info_img, 10, 200, f'現在是否在轉：{is_spin}。', (0, 0, 0), 24)
    info_img = midt.draw_text(info_img, 10, 250, f'結果角度：{result_angle}。', (0, 0, 0), 24)
    info_img = midt.draw_text(info_img, 10, 300, f'開始數字：{start_num}。', (0, 0, 0), 24)
    info_img = midt.draw_text(info_img, 10, 350, f'結果數字：{result_num}', (0, 0, 0), 24)
    info_img = midt.draw_text(info_img, 10, 400, f'開始0號角度：{000}', (0, 0, 0), 24)
    info_img = midt.draw_text(info_img, 10, 450, f'開始球角度：{000}', (0, 0, 0), 24)

    cv2.imshow('info', info_img)

    if (cv2.waitKey(1) & 0xFF) == ord('q'):
        cv2.destroyAllWindows()
        break

t2.join()
t3.join()
t4.join()