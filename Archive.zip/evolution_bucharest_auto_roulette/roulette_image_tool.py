import cv2
import numpy as np
import pytesseract as pt
from tool import my_math_tool as mmt
from tool import my_image_draw_tool as midt

# https://stackoverflow.com/questions/35097837/capture-video-data-from-screen-in-python
pt.pytesseract.tesseract_cmd = r'/usr/local/Cellar/tesseract/5.1.0/bin/tesseract'


# 輪盤0號 影像處理
def roulette_0_img_operation(img):
    img = img[:, :, :3]
    img = cv2.erode(img, np.ones((13, 13)))
    img = cv2.inRange(img, (20, 50, 0), (70, 110, 30))
    return img


def get_0_img_coordinate(img):
    img = roulette_0_img_operation(img)
    a, b = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    if a:
        x, y, w, h = cv2.boundingRect(a[0])
        x_center = x + int(w / 2)
        y_center = y + int(h / 2)
        center = (x_center, y_center)
        radius = int(((w ** 2 + h ** 2) ** 0.5) / 2)
        return center, radius
    return (0, 0), 0


# 輪盤中心點 影像處理
def roulette_center_img_operation(img):
    img = img[:, :, :3]
    img = cv2.inRange(img, (20, 0, 200), (40, 30, 250))
    img = cv2.erode(img, np.ones((2, 2)))
    img = cv2.dilate(img, np.ones((57, 57)))
    return img


def get_center_img_coordinate(img):
    img = roulette_center_img_operation(img)
    a, b = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    if a:
        x, y, w, h = cv2.boundingRect(a[0])
        x_center = x + int(w / 2)
        y_center = y + int(h / 2)
        center = (x_center, y_center)
        radius = int(((w ** 2 + h ** 2) ** 0.5) / 2)
        # 當輪盤不是圓型時矯正角度
        try:
            shift = w / h
        except ZeroDivisionError:
            shift = 1
        return center, radius, shift
    return (0, 0), 0, 1


def get_coordinate(img):
    # 中心標示
    img1 = img[:, :, :3]
    center1, radius1, shift1 = get_center_img_coordinate(img1)
    x_center1 = center1[0]
    y_center1 = center1[1]
    roulette_shift = shift1

    # 0號標示
    img2 = img[:, :, :3]
    center2, radius2 = get_0_img_coordinate(img2)
    x_center2 = center2[0]
    y_center2 = center2[1]

    # 角度計算
    angle_shift = mmt.angle_of_line_shift(x_center1, y_center1, x_center2, y_center2, roulette_shift)
    angle = angle_shift

    dt = {'c': [center1, radius1, shift1], '0': [center2, radius2], 'a': angle}
    return dt


def roulette_img_drawn(img, coordinate):
    img_o = img.copy()

    # 中心標示
    center1, radius1, shift1 = coordinate['c'][0], coordinate['c'][1], coordinate['c'][2]
    cv2.circle(img_o, center1, 3, (0, 255, 255), -1)

    # 0號標示
    center2, radius2 = coordinate['0'][0], coordinate['0'][1]
    cv2.circle(img_o, center2, 3, (0, 255, 0), -1)

    # 連線標示
    cv2.line(img_o, center1, center2, (0, 255, 255), 2)

    # 角度計算
    angle = coordinate['a']
    img_o = midt.draw_text(img_o, 10, 10, f'angle：{angle}', (255, 255, 255), 24)

    return img_o


# 狀態文字 影像處理
def status_img_operation(img):
    img = img[:, :, :3]
    img = cv2.inRange(img, (200, 200, 200), (255, 255, 255))
    img = cv2.bitwise_not(img)
    img = cv2.copyMakeBorder(img, 10, 10, 10, 10, cv2.BORDER_REPLICATE)
    return img


# 結果數字 影像處理
def result_img_operation(img):
    img = img[:, :, :3]
    img = cv2.morphologyEx(img, cv2.MORPH_OPEN, np.ones((3, 3)))
    # img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, np.ones((3, 3)))
    # img = cv2.dilate(img, np.ones((3, 3)))
    # img = cv2.erode(img, np.ones((2, 2)))
    img = cv2.inRange(img, (200, 200, 200), (255, 255, 255))
    img = cv2.bitwise_not(img)
    img = cv2.copyMakeBorder(img, 100, 100, 100, 100, cv2.BORDER_REPLICATE)
    img = cv2.resize(img, (img.shape[1], int((img.shape[0]) * 6 / 7)))
    return img


# 狀態文字 影像辨識
def get_ocr_text(img):
    text = pt.image_to_string(img, 'eng')
    text = text.strip()
    return text


# 結果數字 影像辦識
def get_ocr_text_num(img):
    text = pt.image_to_string(img, 'eng', config='--psm 10 --oem 3 -c tessedit_char_whitelist=0123456789')
    text = text.strip()
    return text
