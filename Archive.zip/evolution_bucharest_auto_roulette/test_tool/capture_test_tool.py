import cv2
import numpy as np
import time
from mss import mss
from PIL import ImageGrab
from screeninfo import get_monitors

# https://stackoverflow.com/questions/35097837/capture-video-data-from-screen-in-python

for m in get_monitors():
    print(str(m))

'''
Monitor(x=0, y=0, width=1792, height=1120, width_mm=None, height_mm=None, name=None, is_primary=True)
Monitor(x=1792, y=604, width=1920, height=1080, width_mm=None, height_mm=None, name=None, is_primary=False)
Monitor(x=-128, y=1120, width=1920, height=1080, width_mm=None, height_mm=None, name=None, is_primary=False)
'''

bounding_box = {'top': 0, 'left': 0, 'width': 500, 'height': 500}

sct = mss()

while True:

    start = time.time()
    sct_img = sct.grab(bounding_box)
    cv2.imshow('screen', np.array(sct_img))

    end = time.time()
    print(f'total loop time:{end - start}')
    print('=' * 100)

    if (cv2.waitKey(1) & 0xFF) == ord('q'):
        cv2.destroyAllWindows()
        break
