import cv2
import numpy as np
import pytesseract as pt
import tesserocr
from PIL import ImageFont, ImageDraw, Image

# https://stackoverflow.com/questions/35097837/capture-video-data-from-screen-in-python
pt.pytesseract.tesseract_cmd = r'/usr/local/Cellar/tesseract/5.3.1/bin/tesseract'

# 狀態文字 影像辨識
def get_ocr_text(img):
    text = pt.image_to_string(img, 'eng')
    text = text.strip()
    return text


# 結果數字 影像辦識
def get_ocr_text_num(img):
    text = pt.image_to_string(img, 'eng', config='--psm 10 --oem 3 -c tessedit_char_whitelist=0123456789')
    text = text.strip()
    return text


def get_ocr_text_fast(img):
    api = tesserocr.PyTessBaseAPI()
    pil_image = Image.fromarray(img)
    api.SetImage(pil_image)
    text = api.GetUTF8Text()
    return text
