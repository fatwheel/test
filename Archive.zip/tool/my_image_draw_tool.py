from PIL import ImageFont, ImageDraw, Image
import numpy as np
import cv2


def draw_bet_textbox(box_height, box_width, upper_bg_color, upper_text_color, upper_text, lower_bg_color_default, lower_bg_color_warning, lower_bg_color_bet, lower_text_color, lower_number):
    font = cv2.FONT_HERSHEY_SIMPLEX
    box_h = box_height
    box_w = box_width
    bet_pic1 = np.full((box_h, box_w, 3), (255, 255, 255), np.uint8)
    bet_img = cv2.rectangle(bet_pic1, (0, 0), (box_w, int(box_h / 2)), upper_bg_color, -1)
    text_size = cv2.getTextSize(upper_text, font, 1, 2)[0]
    text_x = int((bet_img.shape[1] - text_size[0]) / 2)
    text_y = int((bet_img.shape[0] + text_size[1]) / 4)
    bet_img = cv2.putText(bet_img, upper_text, org=(text_x, text_y), fontFace=font, fontScale=1,
                          color=upper_text_color, thickness=2)

    lower_bg_color = lower_bg_color_default
    if 0 < lower_number:
        lower_bg_color = lower_bg_color_bet
    elif -0.02 < lower_number <= 0:
        lower_bg_color = lower_bg_color_warning
    else:
        lower_bg_color = lower_bg_color_default
    bet_img = cv2.rectangle(bet_img, (0, int(box_h / 2)), (box_w, box_h), lower_bg_color, -1)

    lower_text = format(lower_number, '.4f')
    text_size = cv2.getTextSize(lower_text, font, 1, 2)[0]
    text_x = int((bet_img.shape[1] - text_size[0]) / 2)
    text_y = int((bet_img.shape[0] + text_size[1]) * 3 / 4)
    bet_img = cv2.putText(bet_img, lower_text, org=(text_x, text_y), fontFace=font,
                          fontScale=1, color=lower_text_color, thickness=2)
    return bet_img


def draw_text(img, x, y, text, color, size):
    img = Image.fromarray(img)
    ImageDraw.Draw(img).text((x, y), text, color, ImageFont.truetype('../font/kaiu.ttf', size))
    img = np.array(img).copy()
    return img


def draw_circle(img, center, radius=10, color=(0, 255, 0), thickness=-1):
    cv2.circle(img, center, radius, color=color, thickness=thickness)
    return img


# https://gist.github.com/mathandy/389ddbad48810d188bdc997c3a1dab0c
def draw_grid(img, grid_shape, color=(0, 255, 0), thickness=1):
    h, w, _ = img.shape
    rows, cols = grid_shape
    dy, dx = h / rows, w / cols

    # draw vertical lines
    for x in np.linspace(start=dx, stop=w-dx, num=cols-1):
        x = int(round(x))
        cv2.line(img, (x, 0), (x, h), color=color, thickness=thickness)

    # draw horizontal lines
    for y in np.linspace(start=dy, stop=h-dy, num=rows-1):
        y = int(round(y))
        cv2.line(img, (0, y), (w, y), color=color, thickness=thickness)

    return img


# https://gist.github.com/mathandy/389ddbad48810d188bdc997c3a1dab0c
def draw_grid_by_px(img, grid_by_px, color=(0, 255, 0), thickness=1):
    h, w, _ = img.shape
    dy, dx = grid_by_px, grid_by_px

    # draw vertical lines
    for x in range(0, int(w), grid_by_px):
        x = int(round(x))
        cv2.line(img, (x, 0), (x, h), color=color, thickness=thickness)

    # draw horizontal lines
    for y in range(0, int(h), grid_by_px):
        y = int(round(y))
        cv2.line(img, (0, y), (w, y), color=color, thickness=thickness)

    return img