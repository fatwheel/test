import time
import pyautogui

while True: #Start loop
    print (pyautogui.position())
    time.sleep(1)