import math


# https://stackoverflow.com/a/64563327/3167569
def angle_of_vector(x, y):
    return math.degrees(math.atan2(-y, x))


def angle_of_line(x1, y1, x2, y2):
    angle = math.degrees(math.atan2(-(y2-y1), x2-x1))
    angle = int(angle)
    if angle < 0:
        angle = angle + 360
    return angle


def angle_of_line_shift(x1, y1, x2, y2, shift):
    angle = math.degrees(math.atan2(-(y2-y1)*shift, x2-x1))
    angle = int(angle)
    if angle < 0:
        angle = angle + 360
    return angle