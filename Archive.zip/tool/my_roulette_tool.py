


euro_roulette_count = 37
euro_roulette = (0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26)
euro_roulette_r = (0, 26, 3, 35, 12, 28, 7, 29, 18, 22, 9, 31, 14, 20, 1, 33, 16, 24, 5, 10, 23, 8, 30, 11, 36, 13, 27, 6, 34, 17, 25, 2, 21, 4, 19, 15, 32)


def get_euro_num_angle(zero_angle, result_text):
    result_num = int(result_text) if result_text.isdigit() else 99
    if result_num in euro_roulette_r:
        result_num_index = euro_roulette_r.index(result_num)
        result_angle = zero_angle + result_num_index * 360 / euro_roulette_count
        if result_angle > 360:
            result_angle = result_angle - 360
        return int(result_angle)
    return ''


# print(get_euro_num_angle(0, 3))