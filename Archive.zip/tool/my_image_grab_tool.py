import numpy as np
from mss import mss

sct = mss()


# 擷取螢幕範圍
def get_grab_image(bounding_box):
    img = np.array(sct.grab(bounding_box))
    return img
