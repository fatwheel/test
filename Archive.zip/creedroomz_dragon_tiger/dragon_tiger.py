import cv2
import numpy as np
import time
from screeninfo import get_monitors
from mss import mss
from tool import my_image_ocr_tool as miot
import logging
from tool import my_image_draw_tool as midt
from playsound import playsound
import pyautogui

# 是否要自動下注
is_auto_bet = True
# 是否要聲音提示
is_warning_sound = True

# 是否要把第一張削牌的卡記入 (可以不用記)
first_card = '5'
first_card_enable = False

# 螢幕截取設定
# screen type: '1792x1120', '1920x1080'
screen_type = '1792x1120'
# browser type: 'safari', 'chrome'
browser_type = 'safari'

# 是否要顯示定位的截屏
is_show_all_screen = False
# 是否要顯示資訊畫面
is_show_info_screen = True
# 是否要顯示下注畫面
is_show_bet_screen = True
# 是否要顯示辨視處理後的畫面
is_show_ocr_process_screen = False

# 重置牌靴秒數
reset_threshold = 40
# 維持連線下注次數
refresh_threshold = 25
# 提示本牌靴該注意的ev門檻
dog_bark_threshold = -0.01

# log 等級
logging.basicConfig(level=logging.INFO)

# 各種牌的設定
t_odd = ('1', '3', '5', '9', '11', '13')
t_even = ('2', '4', '6', '8', '10', '12')
t_big = ('8', '9', '10', '11', '12', '13')
t_small = ('1', '2', '3', '4', '5', '6')
t_seven = '7'

total_cards = 416
left_cards = 416
left_odd = 192
left_even = 192
left_big = 192
left_small = 192
left_seven = 32

# 螢幕截取
sct = mss()
monitor_number = 1
monitor = sct.monitors[monitor_number]

for m in get_monitors():
    print(str(m))

# 全螢幕抓取
bounding_box = monitor
x_coord = monitor['left']
y_coord = monitor['top']
x_width = monitor['width']
y_height = monitor['height']
# print('bounding_box:', bounding_box)

# 螢幕截取設定
# screen_type = '1792x1120'
# browser_type = 'safari'
capture_params = {'1920x1080':
                      {'chrome':
                           {'ocr1':
                                {'x': int(x_width * 0.373), 'y': int(y_height * 0.750)},
                            'ocr2': {'x': int(x_width * 0.472), 'y': int(y_height * 0.750)},
                            'ocr_box_size': {'width': int(x_width * 0.02),
                                             'height': int(y_height * 0.024)},
                            'bet_counting': {'x': int(x_width * 0.424), 'y': int(y_height * 0.62)},
                            'bet_counting_box_size': {'width': int(x_width * 0.015),
                                                      'height': int(y_height * 0.03)},
                            'wager': {'left': (int(x_width * 0.34), int(y_height * 0.576)),
                                      '1': (int(x_width * 0.375), int(y_height * 0.576)),
                                      '2': (int(x_width * 0.405), int(y_height * 0.576)),
                                      '3': (int(x_width * 0.435), int(y_height * 0.576)),
                                      '4': (int(x_width * 0.465), int(y_height * 0.576)),
                                      '5': (int(x_width * 0.495), int(y_height * 0.576)),
                                      'right': (int(x_width * 0.525), int(y_height * 0.576))},
                            'bet': {'dragon_left': (int(x_width * 0.34), int(y_height * 0.78)),
                                    'odd_left': (int(x_width * 0.306), int(y_height * 0.846)),
                                    'even_left': (int(x_width * 0.366), int(y_height * 0.846)),
                                    'big_left': (int(x_width * 0.306), int(y_height * 0.88)),
                                    'small_left': (int(x_width * 0.366), int(y_height * 0.88)),
                                    'odd_right': (int(x_width * 0.498), int(y_height * 0.846)),
                                    'even_right': (int(x_width * 0.558), int(y_height * 0.846)),
                                    'big_right': (int(x_width * 0.498), int(y_height * 0.88)),
                                    'small_right': (int(x_width * 0.558), int(y_height * 0.88)),
                                    }
                            },
                       'safari':
                           {'ocr1': {'x': int(x_width * 0.369), 'y': int(y_height * 0.7336)},
                            'ocr2': {'x': int(x_width * 0.475), 'y': int(y_height * 0.7336)},
                            'ocr_box_size': {'width': int(x_width * 0.02),
                                             'height': int(y_height * 0.024)},
                            'bet_counting': {'x': int(x_width * 0.424), 'y': int(y_height * 0.62)},
                            'bet_counting_box_size': {'width': int(x_width * 0.015),
                                                      'height': int(y_height * 0.03)},
                            'wager': {'left': (int(x_width * 0.34), int(y_height * 0.576)),
                                      '1': (int(x_width * 0.375), int(y_height * 0.576)),
                                      '2': (int(x_width * 0.405), int(y_height * 0.576)),
                                      '3': (int(x_width * 0.435), int(y_height * 0.576)),
                                      '4': (int(x_width * 0.465), int(y_height * 0.576)),
                                      '5': (int(x_width * 0.495), int(y_height * 0.576)),
                                      'right': (int(x_width * 0.525), int(y_height * 0.576))},
                            'bet': {'dragon_left': (int(x_width * 0.34), int(y_height * 0.78)),
                                    'odd_left': (int(x_width * 0.306), int(y_height * 0.846)),
                                    'even_left': (int(x_width * 0.366), int(y_height * 0.846)),
                                    'big_left': (int(x_width * 0.306), int(y_height * 0.88)),
                                    'small_left': (int(x_width * 0.366), int(y_height * 0.88)),
                                    'odd_right': (int(x_width * 0.498), int(y_height * 0.846)),
                                    'even_right': (int(x_width * 0.558), int(y_height * 0.846)),
                                    'big_right': (int(x_width * 0.498), int(y_height * 0.88)),
                                    'small_right': (int(x_width * 0.558), int(y_height * 0.88)),
                                    }
                            },
                       },
                  '1792x1120':
                      {'safari':
                           {'ocr1': {'x': int(x_width * 0.358), 'y': int(y_height * 0.727)},
                            'ocr2': {'x': int(x_width * 0.474), 'y': int(y_height * 0.727)},
                            'ocr_box_size': {'width': int(x_width * 0.024),
                                             'height': int(y_height * 0.03)},
                            'bet_counting': {'x': int(x_width * 0.42), 'y': int(y_height * 0.617)},
                            'bet_counting_box_size': {'width': int(x_width * 0.015),
                                                      'height': int(y_height * 0.03)},
                            'wager': {'left': (int(x_width * 0.324), int(y_height * 0.5735)),
                                      '1': (int(x_width * 0.364), int(y_height * 0.5735)),
                                      '2': (int(x_width * 0.397), int(y_height * 0.5735)),
                                      '3': (int(x_width * 0.43), int(y_height * 0.5735)),
                                      '4': (int(x_width * 0.464), int(y_height * 0.5735)),
                                      '5': (int(x_width * 0.497), int(y_height * 0.5735)),
                                      'right': (int(x_width * 0.531), int(y_height * 0.5733))},
                            'bet': {'dragon_left': (int(x_width * 0.321), int(y_height * 0.778)),
                                    'odd_left': (int(x_width * 0.291), int(y_height * 0.841)),
                                    'even_left': (int(x_width * 0.351), int(y_height * 0.841)),
                                    'big_left': (int(x_width * 0.291), int(y_height * 0.875)),
                                    'small_left': (int(x_width * 0.351), int(y_height * 0.875)),
                                    'odd_right': (int(x_width * 0.50), int(y_height * 0.841)),
                                    'even_right': (int(x_width * 0.565), int(y_height * 0.841)),
                                    'big_right': (int(x_width * 0.50), int(y_height * 0.875)),
                                    'small_right': (int(x_width * 0.565), int(y_height * 0.875)),
                                    }
                            },
                       },
                  }

# 截圖：左方數字辦視位置
capture_data = capture_params[screen_type][browser_type]
ocr1 = capture_data['ocr1']
ocr1_x = ocr1['x']
ocr1_y = ocr1['y']
# 截圖：右方數字辦視位置
ocr2 = capture_data['ocr2']
ocr2_x = ocr2['x']
ocr2_y = ocr2['y']
# 截圖：數字辦視框大小
ocr_box_size = capture_data['ocr_box_size']
# 截圖：左方數字辦視框
ocr_box1 = [(ocr1_x, ocr1_y), (ocr1_x + ocr_box_size['width'], ocr1_y + ocr_box_size['height'])]
# 截圖：右方數字辦視框
ocr_box2 = [(ocr2_x, ocr2_y), (ocr2_x + ocr_box_size['width'], ocr2_y + ocr_box_size['height'])]
# 座標：左方數字辦視座標
ocr_box1_coord = {'left': x_coord + ocr1_x, 'top': y_coord + ocr1_y, 'width': ocr_box_size['width'],
                  'height': ocr_box_size['height']}

# 座標：右方數字辦視座標
ocr_box2_coord = {'left': x_coord + ocr2_x, 'top': y_coord + ocr2_y, 'width': ocr_box_size['width'],
                  'height': ocr_box_size['height']}

# print('ocr_box1:', ocr_box1)
# print('ocr_box1_coord', ocr_box1_coord)
# 截圖：可下注倒數數字框
bet_counting_x = capture_data['bet_counting']['x']
bet_counting_y = capture_data['bet_counting']['y']
bet_counting_box_size = capture_data['bet_counting_box_size']
bet_counting_box = [(bet_counting_x, bet_counting_y),
                    (bet_counting_x + bet_counting_box_size['width'], bet_counting_y + bet_counting_box_size['height'])]
bet_counting_box_coord = {'left': x_coord + bet_counting_x, 'top': y_coord + bet_counting_y,
                          'width': bet_counting_box_size['width'], 'height': bet_counting_box_size['height']}

# 截圖：籌碼位置
wager_point_left = capture_data['wager']['left']
wager_point_1 = capture_data['wager']['1']
wager_point_2 = capture_data['wager']['2']
wager_point_3 = capture_data['wager']['3']
wager_point_4 = capture_data['wager']['4']
wager_point_5 = capture_data['wager']['5']
wager_point_right = capture_data['wager']['right']

# 截圖：下注位置
bet_dragon_left = capture_data['bet']['dragon_left']

bet_odd_left = capture_data['bet']['odd_left']
bet_even_left = capture_data['bet']['even_left']
bet_big_left = capture_data['bet']['big_left']
bet_small_left = capture_data['bet']['small_left']

bet_odd_right = capture_data['bet']['odd_right']
bet_even_right = capture_data['bet']['even_right']
bet_big_right = capture_data['bet']['big_right']
bet_small_right = capture_data['bet']['small_right']

# 儲存已抽取點數
draw_card_list = []

# 判斷是否要將辨視後的資料存入list
can_add_ocr1_text = True
can_add_ocr2_text = True

# 將第一張削牌的點數記入
if first_card_enable:
    draw_card_list.append(first_card)
    left_cards = left_cards - 1
    if first_card in t_odd: left_odd = left_odd - 1
    if first_card in t_even: left_even = left_even - 1
    if first_card in t_big: left_big = left_big - 1
    if first_card in t_small: left_small = left_small - 1
    if first_card in t_seven: left_seven = left_seven - 1

dog_bark = True

refresh_count_down = refresh_threshold
is_refresh_bet = False
is_bet_time = False

last_ocr_time = time.time()
now_time = time.time()

is_ocr_finish = False
is_win_bet_time = False
is_ev_positive = False

is_odd_bet = False
is_even_bet = False
is_big_bet = False
is_small_bet = False

# cv2.startWindowThread()

while True:

    start = time.time()

    now_time = time.time()

    # reset shoe START
    if reset_threshold <= (now_time - last_ocr_time):
        draw_card_list = []
        can_add_ocr1_text = True
        can_add_ocr2_text = True

        total_cards = 416
        left_cards = 416
        left_odd = 192
        left_even = 192
        left_big = 192
        left_small = 192
        left_seven = 32

        dog_bark = True
        refresh_count_down = 5
        is_refresh_bet = False
        if is_warning_sound:
            playsound('../sound/mixkit-classic-alarm-995.wav')
    # reset shoe END

    # show all monitor image START
    if is_show_all_screen:
        sct_img = sct.grab(bounding_box)
        sct_img = np.array(sct_img)

        # print('sct_img_shape:', sct_img.shape)
        # sct_img = cv2.inRange(sct_img, np.array([240, 240, 240, 240]), np.array([255, 255, 255, 255]))

        if not (sct_img.shape[1] == bounding_box['width'] and sct_img.shape[0] == bounding_box['height']):
            sct_img = cv2.resize(sct_img, (bounding_box['width'], bounding_box['height']))

        sct_img = cv2.rectangle(sct_img, ocr_box1[0], ocr_box1[1], (255, 0, 255), 2)
        sct_img = cv2.rectangle(sct_img, ocr_box2[0], ocr_box2[1], (255, 0, 255), 2)
        sct_img = cv2.rectangle(sct_img, bet_counting_box[0], bet_counting_box[1], (255, 0, 255), 2)
        sct_img = cv2.circle(sct_img, wager_point_left, radius=10, color=(47, 255, 173), thickness=3)
        sct_img = cv2.circle(sct_img, wager_point_1, radius=10, color=(47, 255, 173), thickness=3)
        sct_img = cv2.circle(sct_img, wager_point_2, radius=10, color=(47, 255, 173), thickness=3)
        sct_img = cv2.circle(sct_img, wager_point_3, radius=10, color=(47, 255, 173), thickness=3)
        sct_img = cv2.circle(sct_img, wager_point_4, radius=10, color=(47, 255, 173), thickness=3)
        sct_img = cv2.circle(sct_img, wager_point_5, radius=10, color=(47, 255, 173), thickness=3)
        sct_img = cv2.circle(sct_img, wager_point_right, radius=10, color=(47, 255, 173), thickness=3)

        sct_img = cv2.circle(sct_img, bet_dragon_left, radius=10, color=(47, 255, 173), thickness=5)
        sct_img = cv2.circle(sct_img, bet_odd_left, radius=10, color=(47, 255, 173), thickness=5)
        sct_img = cv2.circle(sct_img, bet_even_left, radius=10, color=(47, 255, 173), thickness=5)
        sct_img = cv2.circle(sct_img, bet_big_left, radius=10, color=(47, 255, 173), thickness=5)
        sct_img = cv2.circle(sct_img, bet_small_left, radius=10, color=(47, 255, 173), thickness=5)
        sct_img = cv2.circle(sct_img, bet_odd_right, radius=10, color=(47, 255, 173), thickness=5)
        sct_img = cv2.circle(sct_img, bet_even_right, radius=10, color=(47, 255, 173), thickness=5)
        sct_img = cv2.circle(sct_img, bet_big_right, radius=10, color=(47, 255, 173), thickness=5)
        sct_img = cv2.circle(sct_img, bet_small_right, radius=10, color=(47, 255, 173), thickness=5)

        # sct_img = midt.draw_grid_by_px(sct_img, 100)
        # sct_img = midt.draw_grid(sct_img, (48,48))
        # sct_img = midt.draw_circle(sct_img, (ocr_x1, ocr_y1))
        cv2.imshow('screen', sct_img)
        cv2.setWindowProperty('screen', cv2.WND_PROP_TOPMOST, 1)
    # show all monitor image END

    # ocr START
    ocr1_img = np.array(sct.grab(ocr_box1_coord))
    ocr1_img = cv2.inRange(ocr1_img, np.array([240, 240, 240, 240]), np.array([255, 255, 255, 255]))  # 轉為黑白的
    ocr1_text = miot.get_ocr_text_num(ocr1_img)
    ocr2_img = np.array(sct.grab(ocr_box2_coord))
    ocr2_img = cv2.inRange(ocr2_img, np.array([240, 240, 240, 240]), np.array([255, 255, 255, 255]))  # 轉為黑白的
    ocr2_text = miot.get_ocr_text_num(ocr2_img)
    bet_count_img = np.array(sct.grab(bet_counting_box_coord))
    bet_count_img = cv2.inRange(bet_count_img, np.array([240, 240, 240, 240]), np.array([255, 255, 255, 255]))  # 轉為黑白的
    bet_count_text = miot.get_ocr_text_num(bet_count_img)
    logging.debug('ocr1 ocr2 bet_count text: %s + %s + %s', ocr1_text, ocr2_text, bet_count_text)
    # ocr END

    # show ocr process screen START
    if is_show_ocr_process_screen:
        ocr_check_img = np.zeros((ocr1_img.shape[0], ocr1_img.shape[1] * 2), np.uint8)
        ocr_check_img[0:ocr1_img.shape[0], 0:ocr1_img.shape[1]] = ocr1_img[:, :]
        ocr_check_img[0:ocr1_img.shape[0], ocr1_img.shape[1]:ocr1_img.shape[1] * 2] = ocr2_img[:, :]

        cv2.imshow('ocr_check_img', ocr_check_img)
        cv2.setWindowProperty('ocr_check_img', cv2.WND_PROP_TOPMOST, 1)

        test_pic = np.full((100, 200, 3), (255, 255, 255), np.uint8)
        test_pic = midt.draw_text(test_pic, 10, 20, f'ocr 1：{ocr1_text}', (0, 0, 0), 24)
        test_pic = midt.draw_text(test_pic, 10, 40, f'ocr 2：{ocr2_text}', (0, 0, 0), 24)

        cv2.imshow('test_pic', test_pic)
        cv2.setWindowProperty('test_pic', cv2.WND_PROP_TOPMOST, 1)
    # show ocr process screen END

    # 允許加入辦視結果 and 有辨視文字
    if can_add_ocr1_text and ocr1_text:
        refresh_count_down = refresh_count_down - 1
        last_ocr_time = time.time()
        is_win_bet_time = True
        draw_card_list.append(ocr1_text)
        left_cards = left_cards - 1
        if ocr1_text in t_odd: left_odd = left_odd - 1
        if ocr1_text in t_even: left_even = left_even - 1
        if ocr1_text in t_big: left_big = left_big - 1
        if ocr1_text in t_small: left_small = left_small - 1
        if ocr1_text in t_seven: left_seven = left_seven - 1
        can_add_ocr1_text = False
    if can_add_ocr2_text and ocr2_text:
        draw_card_list.append(ocr2_text)
        left_cards = left_cards - 1
        if ocr2_text in t_odd: left_odd = left_odd - 1
        if ocr2_text in t_even: left_even = left_even - 1
        if ocr2_text in t_big: left_big = left_big - 1
        if ocr2_text in t_small: left_small = left_small - 1
        if ocr2_text in t_seven: left_seven = left_seven - 1
        can_add_ocr2_text = False
    # 沒有辨視文字 代表可以允許下一次辨視結果加入list
    if not ocr1_text:
        can_add_ocr1_text = True
    if not ocr2_text:
        can_add_ocr2_text = True

    # 兩邊是否都已經判斷完成
    is_ocr_finish = False
    if not ocr1_text and not ocr2_text:
        is_ocr_finish = True

    if bet_count_text:
        is_bet_time = True
    else:
        is_bet_time = False

    logging.debug(draw_card_list)
    logging.debug('left_cards: %i', left_cards)
    logging.debug('left_odd: %i', left_odd)
    logging.debug('left_even: %i', left_even)
    logging.debug('left_big: %i', left_big)
    logging.debug('left_small: %i', left_small)
    logging.debug('left_seven: %i', left_seven)

    odd_probability = left_odd / left_cards
    even_probability = left_even / left_cards
    big_probability = left_big / left_cards
    small_probability = left_small / left_cards

    odd_expecation = 1 * odd_probability - (1 - odd_probability)
    even_expecation = 1 * even_probability - (1 - even_probability)
    big_expecation = 1 * big_probability - (1 - big_probability)
    small_expecation = 1 * small_probability - (1 - small_probability)
    logging.debug('odd expecation: %f', odd_expecation)
    logging.debug('even expecation: %f', even_expecation)
    logging.debug('big expecation: %f', big_expecation)
    logging.debug('small expecation: %f', small_expecation)

    # 本條牌第一次準備下注提醒
    if odd_expecation > dog_bark_threshold or even_expecation > dog_bark_threshold or big_expecation > dog_bark_threshold or small_expecation > dog_bark_threshold:
        if dog_bark and is_warning_sound:
            playsound('../sound/mixkit-dog-barking-twice-1.wav')
        dog_bark = False

    if is_auto_bet:
        # 兩邊都判斷完成後的結果 才可以做為下注依據
        if is_ocr_finish:
            is_odd_bet = True if odd_expecation > 0 else False
            is_even_bet = True if even_expecation > 0 else False
            is_big_bet = True if big_expecation > 0 else False
            is_small_bet = True if small_expecation > 0 else False

            if is_odd_bet or is_even_bet or is_big_bet or is_small_bet:
                is_ev_positive = True
            if is_bet_time and is_win_bet_time and is_ev_positive:
                is_win_bet_time = False
                is_ev_positive = False

                # 下注就先將refresh bet重置
                is_refresh_bet = False
                refresh_count_down = refresh_threshold

                pyautogui.click(wager_point_left[0] + x_coord, wager_point_left[1] + y_coord)
                pyautogui.click(wager_point_left[0] + x_coord, wager_point_left[1] + y_coord)
                time.sleep(0.3)
                pyautogui.click(wager_point_1[0] + x_coord, wager_point_1[1] + y_coord)
                if is_odd_bet:
                    is_odd_bet = False
                    pyautogui.click(bet_odd_left[0] + x_coord, bet_odd_left[1] + y_coord)
                    pyautogui.click(bet_odd_right[0] + x_coord, bet_odd_right[1] + y_coord)
                if is_even_bet:
                    is_even_bet = False
                    pyautogui.click(bet_even_left[0] + x_coord, bet_even_left[1] + y_coord)
                    pyautogui.click(bet_even_right[0] + x_coord, bet_even_right[1] + y_coord)
                if is_big_bet:
                    is_big_bet = False
                    pyautogui.click(bet_big_left[0] + x_coord, bet_big_left[1] + y_coord)
                    pyautogui.click(bet_big_right[0] + x_coord, bet_big_right[1] + y_coord)
                if is_small_bet:
                    is_small_bet = False
                    pyautogui.click(bet_small_left[0] + x_coord, bet_small_left[1] + y_coord)
                    pyautogui.click(bet_small_right[0] + x_coord, bet_small_right[1] + y_coord)

        # 下注維持注碼
        if refresh_count_down <= 0 and is_bet_time:
            is_refresh_bet = True
        if is_refresh_bet:
            is_refresh_bet = False
            refresh_count_down = refresh_threshold
            pyautogui.click(wager_point_left[0] + x_coord, wager_point_left[1] + y_coord)
            pyautogui.click(wager_point_left[0] + x_coord, wager_point_left[1] + y_coord)
            time.sleep(0.3)
            pyautogui.click(wager_point_1[0] + x_coord, wager_point_1[1] + y_coord)
            pyautogui.click(bet_dragon_left[0] + x_coord, bet_dragon_left[1] + y_coord)

    # show bet image START
    if is_show_bet_screen:
        upper_bg_color = (60, 20, 220)
        upper_text_color = (255, 255, 255)
        lower_bg_color_default = (255, 255, 255)
        lower_bg_color_warning = (140, 230, 240)
        lower_bg_color_bet = (203, 192, 255)
        lower_text_color = (0, 0, 0)
        bet_img_odd = midt.draw_bet_textbox(100, 200, upper_bg_color, upper_text_color, 'ODD', lower_bg_color_default,
                                            lower_bg_color_warning, (203, 192, 255), (0, 0, 0), odd_expecation)
        bet_img_even = midt.draw_bet_textbox(100, 200, upper_bg_color, upper_text_color, 'EVEN', lower_bg_color_default,
                                             lower_bg_color_warning, lower_bg_color_bet, lower_text_color,
                                             even_expecation)
        bet_img_big = midt.draw_bet_textbox(100, 200, upper_bg_color, upper_text_color, 'BIG', lower_bg_color_default,
                                            lower_bg_color_warning, lower_bg_color_bet, lower_text_color,
                                            big_expecation)
        bet_img_small = midt.draw_bet_textbox(100, 200, upper_bg_color, upper_text_color, 'SMALL',
                                              lower_bg_color_default, lower_bg_color_warning, lower_bg_color_bet,
                                              lower_text_color, small_expecation)
        '''
        def draw_bet_textbox(box_height, box_width, upper_bg_color, upper_text_color, upper_text, lower_bg_color_default,
                             lower_bg_color_warning, lower_bg_color_bet, lower_text_color, lower_number):
        '''
        '''圖像變數[Y軸範圍起始:Y軸範圍結束, X軸範圍起始: X軸範圍結束]'''
        bet_img = np.full((200, 400, 3), (255, 255, 255), np.uint8)
        bet_img[0:100, 0: 200] = bet_img_odd[:]
        bet_img[0:100, 200: 400] = bet_img_even[:]
        bet_img[100:200, 0: 200] = bet_img_big[:]
        bet_img[100:200, 200: 400] = bet_img_small[:]

        cv2.imshow('bet', bet_img)
        cv2.setWindowProperty('bet', cv2.WND_PROP_TOPMOST, 1)
    # show bet image END

    # show info image START
    if is_show_info_screen:
        info_pic = np.full((1000, 600, 3), (255, 255, 255), np.uint8)

        info_img = midt.draw_text(info_pic, 10, 20, f'最後的6張牌：{draw_card_list[-6:]}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 60, f'已經經過幾手：{int((total_cards - left_cards + 1) / 2)}', (0, 0, 0),
                                  24)
        info_img = midt.draw_text(info_img, 10, 100, f'剩牌 (總數)：{left_cards}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 140, f'剩牌 (ODD)：{left_odd}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 180, f'剩牌 (EVEN)：{left_even}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 220, f'剩牌 (BIG)：{left_big}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 260, f'剩牌 (SMALL)：{left_small}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 300, f'剩牌 (7)：{left_seven}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 340, f'EV (ODD)：{odd_expecation}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 380, f'EV (EVEN)：{even_expecation}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 420, f'EV (BIG)：{big_expecation}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 460, f'EV (SMALL)：{small_expecation}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 500, f'下注倒數：{bet_count_text}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 540, f'維持連線下注倒數 (次數)：{refresh_count_down}', (0, 0, 0), 24)
        info_img = midt.draw_text(info_img, 10, 580,
                                  f'重置牌靴倒數 (秒數)：{reset_threshold - round(now_time - last_ocr_time)}', (0, 0, 0),
                                  24)

        cv2.imshow('info', info_img)
        cv2.setWindowProperty('info', cv2.WND_PROP_TOPMOST, 1)
    # show info image END

    end = time.time()
    logging.info(f'total loop time:{end - start}')
    logging.info('=' * 100)
    # time.sleep(0.2)

    if (cv2.waitKey(1) & 0xFF) == ord('q'):
        cv2.destroyAllWindows()
        break
