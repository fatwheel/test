import cv2
import numpy as np
import pytesseract as pt
from PIL import ImageFont, ImageDraw, Image


def roulette_img_operation(img):
    img = cv2.erode(img, np.ones((13, 13)))
    # img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    return img


def roulette_img_operation2(img):
    img = cv2.inRange(img, (20, 50, 0), (70, 110, 30))
    return img

# 將圖片讀入
img0 = cv2.imread('../roulette_img/0.jpg')
img1 = cv2.imread('../roulette_img/1.jpg')
img2 = cv2.imread('../roulette_img/2.jpg')
img3 = cv2.imread('../roulette_img/3.jpg')
img4 = cv2.imread('../roulette_img/4.jpg')
img5 = cv2.imread('../roulette_img/5.jpg')
img6 = cv2.imread('../roulette_img/6.jpg')
img7 = cv2.imread('../roulette_img/7.jpg')
img8 = cv2.imread('../roulette_img/8.jpg')
img9 = cv2.imread('../roulette_img/9.jpg')
img10 = cv2.imread('../roulette_img/10.jpg')
img11 = cv2.imread('../roulette_img/11.jpg')
img12 = cv2.imread('../roulette_img/12.jpg')
img13 = cv2.imread('../roulette_img/13.jpg')
img14 = cv2.imread('../roulette_img/14.jpg')

Hori0 = np.concatenate((img0, img1, img2, img3, img4), axis=1)
Hori1 = np.concatenate((img5, img6, img7, img8, img9), axis=1)
Hori2 = np.concatenate((img10, img11, img12, img13, img14), axis=1)
Hori = np.concatenate((Hori0, Hori1, Hori2), axis=0)

# 將圖片轉換為可以ocr的狀態
modimg0 = roulette_img_operation(img0)
modimg1 = roulette_img_operation(img1)
modimg2 = roulette_img_operation(img2)
modimg3 = roulette_img_operation(img3)
modimg4 = roulette_img_operation(img4)
modimg5 = roulette_img_operation(img5)
modimg6 = roulette_img_operation(img6)
modimg7 = roulette_img_operation(img7)
modimg8 = roulette_img_operation(img8)
modimg9 = roulette_img_operation(img9)
modimg10 = roulette_img_operation(img10)
modimg11 = roulette_img_operation(img11)
modimg12 = roulette_img_operation(img12)
modimg13 = roulette_img_operation(img13)
modimg14 = roulette_img_operation(img14)

modHori0 = np.concatenate((modimg0, modimg1, modimg2, modimg3, modimg4), axis=1)
modHori1 = np.concatenate((modimg5, modimg6, modimg7, modimg8, modimg9), axis=1)
modHori2 = np.concatenate((modimg10, modimg11, modimg12, modimg13, modimg14), axis=1)
modHori = np.concatenate((modHori0, modHori1, modHori2), axis=0)


mod2img0 = roulette_img_operation2(modimg0)
mod2img1 = roulette_img_operation2(modimg1)
mod2img2 = roulette_img_operation2(modimg2)
mod2img3 = roulette_img_operation2(modimg3)
mod2img4 = roulette_img_operation2(modimg4)
mod2img5 = roulette_img_operation2(modimg5)
mod2img6 = roulette_img_operation2(modimg6)
mod2img7 = roulette_img_operation2(modimg7)
mod2img8 = roulette_img_operation2(modimg8)
mod2img9 = roulette_img_operation2(modimg9)
mod2img10 = roulette_img_operation2(modimg10)
mod2img11 = roulette_img_operation2(modimg11)
mod2img12 = roulette_img_operation2(modimg12)
mod2img13 = roulette_img_operation2(modimg13)
mod2img14 = roulette_img_operation2(modimg14)

mod2Hori0 = np.concatenate((mod2img0, mod2img1, mod2img2, mod2img3, mod2img4), axis=1)
mod2Hori1 = np.concatenate((mod2img5, mod2img6, mod2img7, mod2img8, mod2img9), axis=1)
mod2Hori2 = np.concatenate((mod2img10, mod2img11, mod2img12, mod2img13, mod2img14), axis=1)
mod2Hori = np.concatenate((mod2Hori0, mod2Hori1, mod2Hori2), axis=0)

a, b = cv2.findContours(mod2Hori, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)

for i in range(len(a)):
    print(i)
    x, y, w, h = cv2.boundingRect(a[i])
    # cv2.rectangle(Hori, (x, y), (x+w, y+h), (0, 255, 0), 3)
    x_center = x + int(w/2)
    y_center = y + int(h/2)
    center = (x_center, y_center)
    radius = int(((w**2 + h**2)**0.5)/2)
    print(center)
    print(radius)
    cv2.circle(Hori, center, radius, (0, 255, 0), 3)

cv2.imshow('img', Hori)
cv2.imshow('mod', modHori)
cv2.imshow('mod2', mod2Hori)

cv2.waitKey(0)
cv2.destroyAllWindows()

# HSV_Min = np.array([0, 0, 0])
# HSV_Max = np.array([0, 0, 0])
# #定義六個拉桿的最大最小值
# def H_Lower(val):
#     HSV_Min[0] = val
# def H_Upper(val):
#     HSV_Max[0] = val
# def S_Lower(val):
#     HSV_Min[1] = val
# def S_Upper(val):
#     HSV_Max[1] = val
# def V_Lower(val):
#     HSV_Min[2] = val
# def V_Upper(val):
#     HSV_Max[2] = val
#
# cv2.namedWindow('HSV_TrackBar')
# cv2.createTrackbar('H_Lower', 'HSV_TrackBar', 0, 180, H_Lower)
# cv2.createTrackbar('H_Upper', 'HSV_TrackBar', 0, 180, H_Upper)
# cv2.createTrackbar('S_Lower', 'HSV_TrackBar', 0, 255, S_Lower)
# cv2.createTrackbar('S_Upper', 'HSV_TrackBar', 0, 255, S_Upper)
# cv2.createTrackbar('V_Lower', 'HSV_TrackBar', 0, 255, V_Lower)
# cv2.createTrackbar('V_Upper', 'HSV_TrackBar', 0, 255, V_Upper)
#
# while True:
#     # 先將原圖檔(彩色BGR)轉成HSV色彩空間
#     hsv_key = cv2.cvtColor(Hori, cv2.COLOR_BGR2HSV)
#
#     # 套用拉桿上的數值變化到HSV圖檔和原圖擋上
#     hsv_result = cv2.inRange(hsv_key, HSV_Min, HSV_Max)
#     hsvMask_output = cv2.bitwise_and(Hori, Hori, None, mask=hsv_result)
#
#     # 將圖檔顯示在 'HSV_TrackBar' 視窗並將原圖檔一併顯示出來做比較
#     cv2.imshow('HSV_TrackBar', hsv_result)
#     cv2.imshow('HSV_mask_result', hsvMask_output)
#
#     # 定義一個按鍵(這邊使用'esc')結束視窗
#     if cv2.waitKey(1) == 27:
#         break
# cv2.destroyAllWindows()