import cv2
import numpy as np
import time
from mss import mss
from PIL import ImageGrab
from screeninfo import get_monitors
from tool import my_image_draw_tool as midt
from tool import my_image_ocr_tool as miot

# https://stackoverflow.com/questions/35097837/capture-video-data-from-screen-in-python

for m in get_monitors():
    print(str(m))

sct = mss()
monitor_number = 2
mon = sct.monitors[monitor_number]

print('mon:', mon)
# 範例：mon: {'left': -61, 'top': -1080, 'width': 1920, 'height': 1080}

# 預設一個
# default_bounding_box = {'top': 100, 'left': 100, 'width': 100, 'height': 100, "mon": mon}

# 全螢幕抓取
bounding_box = {'top': mon['top'], 'left': mon['left'], 'width': mon['width'], 'height': mon['height'], "mon": mon}
x_axis = mon['width']
y_axis = mon['height']
ocr1 = {'x': int(x_axis * 0.373), 'y': int(y_axis * 0.75)}
ocr1_x = ocr1['x']
ocr1_y = ocr1['y']
ocr2 = {'x': int(x_axis * 0.472), 'y': int(y_axis * 0.75)}
ocr2_x = ocr2['x']
ocr2_y = ocr2['y']
ocr_box = {'width': int(x_axis * 0.02), 'height': int(y_axis * 0.022)}
ocr_area1 = [(ocr1_x, ocr1_y), (ocr1_x + ocr_box['width'], ocr1_y + ocr_box['height'])]
ocr_area2 = [(ocr2_x, ocr2_y), (ocr2_x + ocr_box['width'], ocr2_y + ocr_box['height'])]
ocr_area1_box = {'left': mon['left'] + ocr1_x, 'top': mon['top'] + ocr1_y, 'width': ocr_box['width'], 'height': ocr_box['height']}
ocr_area2_box = {'left': mon['left'] + ocr2_x, 'top': mon['top'] + ocr2_y, 'width': ocr_box['width'], 'height': ocr_box['height']}

while True:

    start = time.time()
    sct_img = sct.grab(bounding_box)
    sct_img = np.array(sct_img)
    sct_img = cv2.rectangle(sct_img, ocr_area1[0], ocr_area1[1], (255, 0, 255), 2)
    sct_img = cv2.rectangle(sct_img, ocr_area2[0], ocr_area2[1], (255, 0, 255), 2)

    # ocr1_img = np.array(sct.grab(ocr_area1_box))
    # ocr1_text = miot.get_ocr_text_num(ocr1_img)
    # ocr2_img = np.array(sct.grab(ocr_area2_box))
    # ocr2_text = miot.get_ocr_text_num(ocr2_img)
    # print('ocr1 ocr2 text:', ocr1_text + '   ' + ocr2_text)
    # cv2.imshow('ocr1', ocr1_img)
    # cv2.imshow('ocr2', ocr2_img)
    # sct_img = midt.draw_grid_by_px(sct_img, 100)
    # sct_img = midt.draw_grid(sct_img, (48,48))
    # sct_img = midt.draw_circle(sct_img, (ocr_x1, ocr_y1))
    # cv2.imshow('screen', sct_img)

    end = time.time()
    print(f'total loop time:{end - start}')
    print('=' * 100)
    time.sleep(0.2)

    if (cv2.waitKey(1) & 0xFF) == ord('q'):
        cv2.destroyAllWindows()
        break

