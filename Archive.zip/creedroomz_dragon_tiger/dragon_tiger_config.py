import numpy as np
from mss import mss
from tool import my_image_grab_tool as migt


'''
Monitor(x=0, y=0, width=1792, height=1120, width_mm=None, height_mm=None, name=None, is_primary=True)
Monitor(x=1792, y=604, width=1920, height=1080, width_mm=None, height_mm=None, name=None, is_primary=False)
Monitor(x=-128, y=1120, width=1920, height=1080, width_mm=None, height_mm=None, name=None, is_primary=False)
'''

sct = mss()
monitor_number = 2
mon = sct.monitors[monitor_number]

